from .svg import SVG
from .utils import createMissingClasses
from .customTypes import Class, Enum, Relation, Element