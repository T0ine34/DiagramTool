from .python import parse as parse_python
from .svg import SVG